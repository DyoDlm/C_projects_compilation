#include "fractals.h"
#include "get_next_line.h"

static int  check_rules(t_data *data, char *line, int *iteration)
{
    int i;

    i = *iteration;
    if (getlen(line) >= 32)
        return (merrors(1), 1);
    if (i <= 4 && ft_strncmp(line, "1", 2) <= 1)
    {
	    if (line[0] == '1')
		    data->rules[i] = '1';
	    else
		    data->rules[i] = '2';
    }
    *iteration += 1;
    mrules(((i) + 4));
    if (i > 7 || getlen(line) == 1)
        return (0);
    return (1);
}

static int    intro(t_data *data)
{
    int     i;
    char    *line;

    i = 0;
    line = NULL;
    mrules(1);
    while (1)
    {
        line = get_next_line(0);
        if (line)
        {
            if (!check_rules(data, line, &i))
                return (mrules(2), free(line), i);
            if (ft_strlen(line) != 0)
                mrules(3);
            if (line)
                free(line);
        }
        if (i >= BUF - 1)
            break ;
    }
    return (mrules(2), i);
}

void init_data(t_data *data, char state)
{
    if (state == '0')
    {
        data->mlx = NULL;
        data->win = NULL;
    }
    data->mlx2 = NULL;
    data->win2 = NULL;
    data->s.HI = 1080;
    data->s.WI = 1520;
    data->s.size = 0;
    data->s.mpos = 0;
    data->s.zoom = 1;
    data->s.mx = 0;
    data->s.my = 0;
    data->s.log_i = 1;
    data->s.screen_mode = 0;
    data->s.color = WHITE;
    data->s.disolvant = 30;
    data->s.julia_cx = 1.234;
    data->s.julia_cy = 0.432;
    ft_memset(data->rules, 0, sizeof(data->rules));
    init_julia(data);
    init_newton(data);
    init_mandelbrot(data);
    init_control_screen(data);
}
/*
static void tester(void)
{
    double  n = 12.12345;
    char    *str;
    char    *join;
    char    *joined;

    join = malloc(50);
    if (!join)
        return ;
    str = ft_dtoa(n, 4);
    ft_memcpy(join, "hello :", 8);
    joined = ft_strjoin(join, str);
    printf("%s\n", joined);
    free(str);
    free(joined);
}*/

int	main()
{
    t_data data;

    init_data(&data, '0');
    intro(&data);
    data.mlx = mlx_init();
    if (!data.mlx)
        return (EXIT_FAILURE);
    ft_putstr("hello init ok\n");
    data.win = mlx_new_window(data.mlx, data.s.HI, data.s.WI, "WAW !");
    if (!data.win)
        return (free_to_go(&data, '0'), EXIT_FAILURE);
    ft_putstr("hello win ok\n");
    display_home(&data);
    mlx_key_hook(data.win, key_handler, &data);
    mlx_mouse_hook(data.win, mouse_handler, &data); 
    mlx_hook(data.win, 17, 0, close_win, &data);
    mlx_loop(data.mlx);
    return (EXIT_SUCCESS);
}