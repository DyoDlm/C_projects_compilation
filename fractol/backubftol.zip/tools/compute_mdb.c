#include "fractals.h"

void    compute_czxy(t_data *d, t_build *b, int *i)
{
    b->cx = ((b->x - d->s.WI / 2.0) * 4.0 / d->s.WI) * d->s.zoom + d->s.mx;
    b->cy = ((b->y - d->s.HI / 2.0) * 4.0 / d->s.HI) * d->s.zoom + d->s.my;
    if (d->s.screen_mode == 1 || d->s.screen_mode == 2)
    {
        b->zx = 0;
        b->zy = 0;
    }
    if (d->s.screen_mode == 6 || d->s.screen_mode == 3)
    {
        b->zx = b->cx;
        b->zy = b->cy;
    }
    if (d->s.screen_mode == 2)
    {
        b->cx = 1.33;
        b->cy = 0.523;
    }
    *i = 0;
}

int    check_limits(t_data *d, t_build *b, int *i)
{
    if (b->zx * b->zx + b->zy * b->zy < 4.0  && *i < d->f.m.mi)
        return (1);
    return (0);
}

static void    update_z(t_build *b)
{
    double zx = b->zx; // Copie pour lisibilité
    double zy = b->zy;

    // Calcul de (Zn - 1) : Partie réelle et imaginaire
    double diff_re = zx - 1.0;
    double diff_im = zy;

    // (Zn - 1)^3 : Partie réelle et imaginaire
    double diff_re2 = diff_re * diff_re - diff_im * diff_im; // (Re^2 - Im^2)
    double diff_im2 = 2 * diff_re * diff_im;                // (2 * Re * Im)
    double diff_re3 = diff_re2 * diff_re - diff_im2 * diff_im;
    double diff_im3 = diff_re2 * diff_im + diff_im2 * diff_re;

    // Zn^2 : Partie réelle et imaginaire
    double zn_re2 = zx * zx - zy * zy;
    double zn_im2 = 2 * zx * zy;

    // Division (Zn - 1)^3 / (3 * Zn^2) : Partie réelle et imaginaire
    double denom_re = 3 * zn_re2;
    double denom_im = 3 * zn_im2;
    double denom_mag = denom_re * denom_re + denom_im * denom_im; // |3Zn^2|^2
    double div_re = (diff_re3 * denom_re + diff_im3 * denom_im) / denom_mag;
    double div_im = (diff_im3 * denom_re - diff_re3 * denom_im) / denom_mag;

    // Mise à jour de Z_n+1
    b->tp = zx - div_re + b->cx; // Nouvelle partie réelle
    b->zy = zy - div_im + b->cy; // Nouvelle partie imaginaire
    b->zx = b->tp;
}

void    paint_x_axis(t_data *data, t_build *b, int *i)
{
    if (data->s.screen_mode == 1 || data->s.screen_mode == 2)
    {
        b->tp = b->zx * b->zx - b->zy * b->zy + b->cx;
        b->zy = 2.0 * b->zx * b->zy + b->cy;
        b->zx = b->tp;
    }
    if (data->s.screen_mode == 3 || data->s.screen_mode == 6)
        update_z(b);
    if (data->s.screen_mode == 7)
    {
        *i += 0; 
    }
    *i += 1;
}

void    map_pixel(t_data *d, t_build *b, int color)
{
    int ok;

    ok = 0;
    if (b->x >= 0 && b->x < d->s.WI && b->y >= 0 && b->y < d->s.HI)
        ok = 1;
    if (ok != 1)
        return ;
    if (d->s.screen_mode == 1 || d->s.screen_mode == 3)
    {
        d->f.m.pindex = b->y * d->f.m.l + b->x * (d->f.m.b / 8);
        *(int *)(d->f.m.a + d->f.m.pindex) = color;
    }
    if (d->s.screen_mode == 2)
    {
        d->f.j.pindex = b->y * d->f.j.l + b->x * (d->f.j.b / 8);
        *(int *)(d->f.j.a + d->f.j.pindex) = color;
    }
}