#include "fractals.h"

static void build_image(t_data *d)
{
    if (d->s.screen_mode == 1)
        build_mandelbrot_img(d);
    else if (d->s.screen_mode == 2)
        build_julia_img(d);
    else if (d->s.screen_mode == 9)
        build_newton_img(d);
    else if (d->s.screen_mode == 6 || d->s.screen_mode == 3)
        build_nova_img(d);
}

void    print_image(t_data *d, int bdoor)
{
    (void)bdoor;
    mlx_clear_window(d->mlx, d->win);
    if (d->s.screen_mode == 0)
        mlx_string_put(d->mlx, d->win, 100, 100, RED, "VOUS ETES EN MODE ACCEUIL");
    else if (d->s.screen_mode == 1 || d->s.screen_mode == 6 || d->s.screen_mode == 3)
        mlx_put_image_to_window(d->mlx, d->win, d->f.m.img, 0, 0);
    else if (d->s.screen_mode == 2)
        mlx_put_image_to_window(d->mlx, d->win, d->f.j.img, 0, 0);
    else if (d->s.screen_mode == 3)
        mlx_put_image_to_window(d->mlx, d->win, d->f.n.img, 0, 0);
}

void    fractal_mod(t_data *data)
{
    data->s.julia_cx = 1.234;
    data->s.julia_cy = 0.141;
    build_image(data);
    print_image(data, 0);
}