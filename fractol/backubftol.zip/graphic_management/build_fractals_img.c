#include <stdio.h>
#include "fractals.h"
/*
static void build_snowflake_img(t_data *d)
{
    (void)d;
}*/

void    build_nova_img(t_data *d)
{
    int i;
    int color;
    t_build b;

    i = 0;
    init_build(&b);
    replace_image(&d->f.m.img, d->mlx, d->s.WI, d->s.HI);
    d->f.m.a = mlx_get_data_addr(d->f.m.img, &d->f.m.b, &d->f.m.l, &d->f.m.e);
    while (b.y < d->s.HI)
    {
        b.x = 0;
        while (b.x < d->s.WI)
        {
            compute_czxy(d, &b, &i);
            while (check_limits(d, &b, &i))
                paint_x_axis(d, &b, &i);
            if (i == d->f.m.mi)
                color = BLACK;
            else
                color = d->s.color * i / d->s.disolvant;
            map_pixel(d, &b, color);
            b.x++;
        }
        b.y++;
    }
    printf("IMG BUILT 444!\n");
}

void    build_mandelbrot_img(t_data *d)
{
    int     i;
    int     color;
    t_build b;

    init_build(&b);
    replace_image(&d->f.m.img, d->mlx, d->s.WI, d->s.HI);
    d->f.m.a = mlx_get_data_addr(d->f.m.img, &d->f.m.b, &d->f.m.l, &d->f.m.e);
    while (b.y < d->s.HI)
    {
        b.x = 0;
        while (b.x < d->s.WI)
        {
            compute_czxy(d, &b, &i);
            while (check_limits(d, &b, &i))
                paint_x_axis(d, &b, &i);
            if (i == d->f.m.mi)
                color = BLACK;
            else
                color = d->s.color * i / d->s.disolvant;
            map_pixel(d, &b, color);
            b.x += 1;
        }
        b.y += 1;
    }
}

void    build_julia_img(t_data *d)
{
    int     i;
    int     color;
    t_build b;

    init_build(&b);
    replace_image(&d->f.j.img, d->mlx, d->s.WI, d->s.HI);
    d->f.j.a = mlx_get_data_addr(d->f.j.img, &d->f.j.b, &d->f.j.l, &d->f.j.e);
    while (b.y < d->s.HI)
    {
        b.x = 0;
        while (b.x < d->s.WI)
        {
            b.zx = ((b.x - d->s.WI / 2.0) * 4.0 / d->s.WI) * d->s.zoom + d->s.mx;
            b.zy = ((b.y - d->s.HI / 2.0) * 4.0 / d->s.HI) * d->s.zoom + d->s.my;
            b.cx = d->s.julia_cx;
            b.cy = d->s.julia_cy;
            i = 0;
            while (check_limits(d, &b, &i))
            {
                b.tp = b.zx;
                b.zx = b.zx * b.zx - b.zy * b.zy;
                b.zy = 2.0 * b.zx * b.tp + b.cy;
                if (b.zx * b.zx + b.zy * b.zy >= __DBL_MAX__)
                    break ;
                i++;
            }
            if (i == d->f.m.mi)
                color = BLACK;
            else
                color = d->s.color * i / d->s.disolvant;
            map_pixel(d, &b, color);
            b.x++;
        }
        b.y++;
    }
    printf("Julia IMG BUILT!\n");
}

void    build_newton_img(t_data *d)
{
//    replace_image(&d->f.n.img, d->mlx, d->s.WI, d->s.HI);
//    d->f.n.addr = mlx_get_data_addr(d->f.n.img, &d->f.n.bpp, &d->f.n.ll, &d->f.n.edn);
    build_nova_img(d);
//    build_snowflake_img(d);
}